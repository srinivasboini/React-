export { default } from 'ember-masonry-grid/components/masonry-grid/component';
