// Extended Credit Card Component
//
import creditCard from 'ember-credit-card/components/credit-card';

export default creditCard.extend({
    layout: null,
    layoutName: 'components/credit-card-ext'
});
