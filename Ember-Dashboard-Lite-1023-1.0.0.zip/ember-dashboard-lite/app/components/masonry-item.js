export { default } from 'ember-masonry-grid/components/masonry-item/component';
