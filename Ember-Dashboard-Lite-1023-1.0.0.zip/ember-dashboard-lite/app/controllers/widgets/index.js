import Ember from 'ember';

export default Ember.Controller.extend({

    peityLargeOptions: {
        width: '100%',
        height: 32
    }

});
