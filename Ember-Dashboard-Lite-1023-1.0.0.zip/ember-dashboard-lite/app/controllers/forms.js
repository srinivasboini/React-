export default Ember.Controller.extend({
    breadCrumb: 'Forms'
});
