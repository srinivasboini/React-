export default Ember.Controller.extend({
    breadCrumb: 'Widgets',
});
