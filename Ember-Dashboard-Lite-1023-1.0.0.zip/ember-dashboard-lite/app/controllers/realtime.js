export default Ember.Controller.extend({
    breadCrumb: 'Realtime'
});
